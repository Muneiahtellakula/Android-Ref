package com.example.firebaseloginlogout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText user, paswd;
    Button log, register;
    FirebaseAuth authantication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = findViewById(R.id.usn);
        paswd = findViewById(R.id.pwd);
        log = findViewById(R.id.bt1);
        register = findViewById(R.id.bt2);
        authantication = FirebaseAuth.getInstance();
    }

    public void loginActiviy(View view) {
        String name = user.getText().toString();
        String password = paswd.getText().toString();
        authantication.signInWithEmailAndPassword(name, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                        }
                    }
                });/*.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "Login Failed ", Toast.LENGTH_SHORT).show();
            }
        });*/
    }

    public void registerEvent(View view) {
        Intent i = new Intent(this, Activity.class);
        startActivity(i);
    }
}
